// Gestão de listas pré-definidas
let lists = [];
let mcdtDatabase = [];
let selectedMCDTs = new Set();

// Carregar base de dados MCDT
async function loadMCDTDatabase() {
    try {
        const response = await fetch(chrome.runtime.getURL('mcdt_db.json'));
        mcdtDatabase = await response.json();
        console.log(`Base de dados MCDT carregada: ${mcdtDatabase.length} exames`);
    } catch (error) {
        console.error('Erro ao carregar base de dados MCDT:', error);
    }
}

// Carregar listas guardadas
async function loadLists() {
    const result = await chrome.storage.local.get(['mcdtLists']);
    lists = result.mcdtLists || [];
    renderLists();
}

// Calcular custo total de uma lista
function calculateListCost(codes) {
    let total = 0;
    let foundCount = 0;
    
    codes.forEach(code => {
        const mcdt = mcdtDatabase.find(m => m.code === code);
        if (mcdt && mcdt.price && mcdt.price !== 'N/D') {
            const price = parseFloat(mcdt.price);
            if (!isNaN(price)) {
                total += price;
                foundCount++;
            }
        }
    });
    
    return {
        total: total,
        foundCount: foundCount,
        totalCodes: codes.length
    };
}

// Renderizar lista de listas
function renderLists() {
    const listsList = document.getElementById('listsList');
    
    if (lists.length === 0) {
        listsList.innerHTML = '<div class="empty-state">Nenhuma lista criada.<br>Clique em "Nova Lista" para começar.</div>';
        return;
    }
    
    listsList.innerHTML = lists.map((list, index) => {
        const cost = calculateListCost(list.codes);
        const costText = cost.foundCount > 0 
            ? `€${cost.total.toFixed(2)}`
            : 'Preço N/D';
        
        return `
        <div class="list-item">
            <div>
                <div class="list-name">${escapeHtml(list.name)}</div>
                <div class="list-count">${list.codes.length} exame(s) • ${costText}</div>
            </div>
            <div class="actions">
                <button class="btn btn-primary execute-btn" data-index="${index}">▶ Executar</button>
                <button class="btn btn-secondary edit-btn" data-index="${index}">✏️</button>
                <button class="btn btn-danger delete-btn" data-index="${index}">🗑️</button>
            </div>
        </div>
        `;
    }).join('');
    
    // Adicionar event listeners
    document.querySelectorAll('.execute-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const index = parseInt(e.target.dataset.index);
            executeList(index);
        });
    });
    
    document.querySelectorAll('.edit-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const index = parseInt(e.target.dataset.index);
            editList(index);
        });
    });
    
    document.querySelectorAll('.delete-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const index = parseInt(e.target.dataset.index);
            deleteList(index);
        });
    });
}

// Executar lista de MCDT
async function executeList(index) {
    const list = lists[index];
    
    showStatus(`Executando lista "${list.name}"...`, 'info');
    
    try {
        // Obter tab ativa
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        
        // Enviar mensagem para content script
        await chrome.tabs.sendMessage(tab.id, {
            action: 'executeMCDTList',
            codes: list.codes,
            listName: list.name
        });
        
        showStatus(`Lista "${list.name}" enviada para execução!`, 'success');
        
        // Fechar popup após 2 segundos
        setTimeout(() => {
            window.close();
        }, 2000);
        
    } catch (error) {
        console.error('Erro ao executar lista:', error);
        showStatus('Erro: Certifique-se que está na página PEM', 'error');
    }
}

// Editar lista
function editList(index) {
    const list = lists[index];
    document.getElementById('listName').value = list.name;
    document.getElementById('mcdtCodes').value = list.codes.join('\n');
    
    // Mudar para modo edição
    document.getElementById('saveListBtn').textContent = '💾 Atualizar Lista';
    document.getElementById('saveListBtn').dataset.editIndex = index;
    
    showCreateForm();
}

// Eliminar lista
async function deleteList(index) {
    if (confirm(`Tem certeza que deseja eliminar a lista "${lists[index].name}"?`)) {
        lists.splice(index, 1);
        await chrome.storage.local.set({ mcdtLists: lists });
        renderLists();
        showStatus('Lista eliminada com sucesso!', 'success');
    }
}

// Mostrar formulário de criação
function showCreateForm() {
    document.getElementById('listsView').style.display = 'none';
    document.getElementById('createListForm').style.display = 'block';
}

// Mostrar lista de listas
function showListsView() {
    document.getElementById('listsView').style.display = 'block';
    document.getElementById('createListForm').style.display = 'none';
    
    // Limpar formulário
    document.getElementById('listName').value = '';
    document.getElementById('mcdtCodes').value = '';
    document.getElementById('saveListBtn').textContent = '💾 Guardar Lista';
    delete document.getElementById('saveListBtn').dataset.editIndex;
    document.getElementById('createStatus').style.display = 'none';
}

// Guardar lista
async function saveList() {
    const name = document.getElementById('listName').value.trim();
    const codesText = document.getElementById('mcdtCodes').value.trim();
    
    if (!name) {
        showCreateStatus('Por favor, insira um nome para a lista', 'error');
        return;
    }
    
    if (!codesText) {
        showCreateStatus('Por favor, insira pelo menos um código MCDT', 'error');
        return;
    }
    
    // Processar códigos (um por linha)
    const codes = codesText.split('\n')
        .map(code => code.trim())
        .filter(code => code.length > 0);
    
    if (codes.length === 0) {
        showCreateStatus('Nenhum código MCDT válido encontrado', 'error');
        return;
    }
    
    const newList = {
        name: name,
        codes: codes,
        createdAt: new Date().toISOString()
    };
    
    // Verificar se é edição ou criação
    const editIndex = document.getElementById('saveListBtn').dataset.editIndex;
    
    if (editIndex !== undefined) {
        // Edição
        lists[parseInt(editIndex)] = newList;
        showCreateStatus('Lista atualizada com sucesso!', 'success');
    } else {
        // Nova lista
        lists.push(newList);
        showCreateStatus('Lista criada com sucesso!', 'success');
    }
    
    await chrome.storage.local.set({ mcdtLists: lists });
    
    // Voltar para lista após 1 segundo
    setTimeout(() => {
        showListsView();
        renderLists();
    }, 1000);
}

// Abrir modal de pesquisa
function openSearchModal() {
    selectedMCDTs.clear();
    document.getElementById('searchModal').classList.add('show');
    document.getElementById('searchInput').value = '';
    document.getElementById('areaFilter').value = '';
    
    // Popular filtro de áreas
    const areas = [...new Set(mcdtDatabase.map(m => m.area))].sort();
    const areaFilter = document.getElementById('areaFilter');
    areaFilter.innerHTML = '<option value="">Todas as Áreas</option>' + 
        areas.map(area => `<option value="${area}">${area}</option>`).join('');
    
    document.getElementById('searchInput').focus();
    renderSearchResults(mcdtDatabase);
    updateSelectedCount();
}

// Fechar modal de pesquisa
function closeSearchModal() {
    document.getElementById('searchModal').classList.remove('show');
    selectedMCDTs.clear();
}

// Pesquisar MCDT
function searchMCDT(query, area = '') {
    let results = mcdtDatabase;
    
    // Filtrar por área se selecionada
    if (area) {
        results = results.filter(mcdt => mcdt.area === area);
    }
    
    // Filtrar por query se fornecida
    if (query.trim()) {
        const lowerQuery = query.toLowerCase();
        results = results.filter(mcdt => 
            mcdt.name.toLowerCase().includes(lowerQuery) ||
            mcdt.code.includes(query)
        );
    }
    
    renderSearchResults(results);
}

// Renderizar resultados de pesquisa
function renderSearchResults(results) {
    const container = document.getElementById('searchResults');
    
    if (results.length === 0) {
        container.innerHTML = '<div class="no-results">Nenhum exame encontrado.<br>Tente outro termo de pesquisa.</div>';
        return;
    }
    
    container.innerHTML = results.map(mcdt => `
        <div class="mcdt-item ${selectedMCDTs.has(mcdt.code) ? 'selected' : ''}" data-code="${mcdt.code}">
            <div class="mcdt-code">[${mcdt.code}]</div>
            <div class="mcdt-name">${escapeHtml(mcdt.name)}</div>
            <div class="mcdt-price">€${mcdt.price}</div>
        </div>
    `).join('');
    
    // Adicionar event listeners
    document.querySelectorAll('.mcdt-item').forEach(item => {
        item.addEventListener('click', () => {
            const code = item.dataset.code;
            if (selectedMCDTs.has(code)) {
                selectedMCDTs.delete(code);
                item.classList.remove('selected');
            } else {
                selectedMCDTs.add(code);
                item.classList.add('selected');
            }
            updateSelectedCount();
        });
    });
}

// Actualizar contador de selecionados
function updateSelectedCount() {
    const countElement = document.getElementById('selectedCount');
    const countText = document.getElementById('countText');
    const count = selectedMCDTs.size;
    
    if (count > 0) {
        countElement.style.display = 'block';
        countText.textContent = `${count} exame${count > 1 ? 's' : ''} selecionado${count > 1 ? 's' : ''}`;
    } else {
        countElement.style.display = 'none';
    }
}

// Adicionar selecionados à lista
function addSelectedToList() {
    if (selectedMCDTs.size === 0) {
        alert('Selecione pelo menos um exame');
        return;
    }
    
    const textarea = document.getElementById('mcdtCodes');
    const currentCodes = textarea.value.trim();
    const newCodes = Array.from(selectedMCDTs).join('\n');
    
    if (currentCodes) {
        textarea.value = currentCodes + '\n' + newCodes;
    } else {
        textarea.value = newCodes;
    }
    
    closeSearchModal();
}

// Mostrar status
function showStatus(message, type) {
    const status = document.getElementById('status');
    status.textContent = message;
    status.className = `status ${type}`;
    status.style.display = 'block';
    
    setTimeout(() => {
        status.style.display = 'none';
    }, 5000);
}

// Mostrar status de criação
function showCreateStatus(message, type) {
    const status = document.getElementById('createStatus');
    status.textContent = message;
    status.className = `status ${type}`;
    status.style.display = 'block';
    
    setTimeout(() => {
        status.style.display = 'none';
    }, 5000);
}

// Escape HTML
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Event listeners
document.addEventListener('DOMContentLoaded', async () => {
    await loadMCDTDatabase();
    await loadLists();
    
    document.getElementById('newListBtn').addEventListener('click', showCreateForm);
    document.getElementById('backBtn').addEventListener('click', showListsView);
    document.getElementById('saveListBtn').addEventListener('click', saveList);
    
    // Modal de pesquisa
    document.getElementById('searchMCDTBtn').addEventListener('click', openSearchModal);
    document.getElementById('closeModal').addEventListener('click', closeSearchModal);
    document.getElementById('cancelSearch').addEventListener('click', closeSearchModal);
    document.getElementById('addSelected').addEventListener('click', addSelectedToList);
    
    // Pesquisa em tempo real
    document.getElementById('searchInput').addEventListener('input', (e) => {
        const area = document.getElementById('areaFilter').value;
        searchMCDT(e.target.value, area);
    });
    
    // Filtro por área
    document.getElementById('areaFilter').addEventListener('change', (e) => {
        const query = document.getElementById('searchInput').value;
        searchMCDT(query, e.target.value);
    });
    
    // Fechar modal ao clicar fora
    document.getElementById('searchModal').addEventListener('click', (e) => {
        if (e.target.id === 'searchModal') {
            closeSearchModal();
        }
    });
});
