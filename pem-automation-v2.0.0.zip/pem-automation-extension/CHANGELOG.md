# 📋 Histórico de Versões - PEM Automation

## Versão 1.1.0 - Optimização de Velocidade (6 Nov 2025)

### 🚀 Melhorias de Performance

**Detecção Inteligente de Sucesso** - A extensão agora detecta automaticamente quando um exame foi adicionado com sucesso, em vez de usar tempos de espera fixos. Isto resulta em velocidade máxima mantendo fiabilidade.

**Tempos Optimizados** - Redução significativa dos tempos de espera:
- Após digitação: 500ms → 100ms (80% mais rápido)
- Após clicar adicionar: 1000ms → 200ms (80% mais rápido)
- Entre exames: 800ms → 150ms (81% mais rápido)

**Velocidade Alvo Atingida** - Aproximadamente 0.5 segundos por exame, permitindo adicionar 20 exames em ~10 segundos.

### 🎯 Estratégias de Detecção

A extensão utiliza múltiplas estratégias para detectar sucesso:

1. **Detecção de Campo Limpo** - Verifica se o campo de código MCDT foi limpo automaticamente pelo sistema (indicação de sucesso)

2. **Detecção na Tabela** - Verifica se o código apareceu na tabela de requisição

3. **Detecção de Erros** - Identifica mensagens de erro visíveis na página

4. **Fallback Inteligente** - Se nenhuma das estratégias anteriores for conclusiva, assume sucesso após timeout

### 📊 Estatísticas de Execução

A extensão agora apresenta estatísticas detalhadas na consola do navegador após cada execução:
- Tempo total de execução
- Tempo médio por exame
- Velocidade em exames por segundo
- Número de sucessos e erros
- Método de detecção utilizado para cada exame

### 🔧 Melhorias Técnicas

**Logging Detalhado** - Cada exame regista o tempo de execução e método de detecção utilizado

**Notificações Mais Rápidas** - Notificações durante execução têm duração reduzida (1.5s) para não obstruir a visualização

**Gestão de Erros Melhorada** - Erros são detectados mais rapidamente e reportados com maior precisão

---

## Versão 1.0.0 - Lançamento Inicial (6 Nov 2025)

### ✨ Funcionalidades Principais

**Listas Pré-definidas** - Criação e gestão de múltiplas listas de códigos MCDT

**Execução Automática** - Processamento automático de múltiplos códigos em sequência

**Botão Flutuante** - Interface de acesso rápido no canto inferior direito

**Interface Moderna** - Design profissional e intuitivo

**Notificações em Tempo Real** - Feedback visual durante a execução

### 🔒 Segurança

**Armazenamento Local** - Todos os dados guardados localmente no navegador

**Sem Recolha de Dados** - Nenhuma informação enviada para servidores externos

**Permissões Mínimas** - Apenas permissões estritamente necessárias

### 📦 Componentes

- `manifest.json` - Configuração da extensão
- `popup.html` / `popup.js` - Interface do utilizador
- `content.js` / `content.css` - Automação e botão flutuante
- `icons/` - Ícones da extensão
- `README.md` - Documentação completa

---

**Desenvolvido por Manus AI**


## Versão 1.2.0 - Pesquisa e Seleção de MCDT (9 Nov 2025)

### ✨ Funcionalidades Principais

**Base de Dados MCDT Integrada** - A extensão agora inclui uma base de dados completa com todos os códigos MCDT da tabela fornecida, permitindo acesso rápido a milhares de exames.

**Interface de Pesquisa Avançada** - Ao criar ou editar uma lista, agora tem acesso a uma interface de pesquisa poderosa:
- **Pesquisa por Nome ou Código:** Encontre exames instantaneamente.
- **Filtros por Área:** Refine a pesquisa por área clínica (Análises Clínicas, Imagiologia, etc.).
- **Seleção Múltipla:** Adicione múltiplos exames à sua lista com um clique.

**Criação de Listas Simplificada** - Não precisa mais de digitar ou copiar/colar códigos. Basta pesquisar, selecionar e adicionar.

### 🎨 Melhorias de Interface

**Modal de Pesquisa** - Uma janela modal elegante para pesquisar e selecionar exames sem sair do popup principal.

**Lista de Selecionados** - Veja os exames que já selecionou antes de os adicionar à lista.

**Contador de Selecionados** - Um contador visual mostra quantos exames já selecionou.

### 🔧 Melhorias Técnicas

**Base de Dados JSON** - Os dados MCDT são armazenados num ficheiro JSON otimizado para carregamento rápido.

**Carregamento Assíncrono** - A base de dados é carregada em segundo plano para não bloquear a interface.

**Filtragem Eficiente** - A pesquisa e filtragem são realizadas de forma eficiente no lado do cliente.


## Versão 1.2.1 - Interface Simplificada (9 Nov 2025)

### 🎯 Melhorias de Usabilidade

**Botão Flutuante Removido** - O botão flutuante foi removido por feedback do utilizador. A extensão é agora acedida exclusivamente através do ícone na barra de ferramentas do navegador, resultando numa interface mais limpa e menos intrusiva.

**Acesso Simplificado** - Para usar a extensão:
1. Clique no ícone 🏥 **PEM Automation** na barra de ferramentas
2. Ou clique no ícone de extensões (puzzle) e selecione **PEM Automation**

### 🧹 Limpeza de Código

**CSS Optimizado** - Removidos todos os estilos relacionados com o botão flutuante e painel inline, reduzindo o tamanho dos ficheiros.

**JavaScript Simplificado** - Content script mais leve e focado apenas na automação de MCDT.


## Versão 1.3.0 - Pesquisa de MCDT com Preços (9 Nov 2025)

### ✨ Funcionalidades Principais

**Interface de Pesquisa Completa** - Modal de pesquisa elegante e funcional para encontrar exames MCDT sem memorizar códigos.

**Preços dos Exames** - Todos os exames mostram o preço actualizado (tabela de 2025).

**Pesquisa em Tempo Real** - Resultados instantâneos enquanto digita o nome ou código do exame.

**Seleção Múltipla Visual** - Clique nos exames para selecionar, veja quantos selecionou, e adicione todos de uma vez à lista.

**Base de Dados Actualizada** - 266 códigos MCDT da área de Análises Clínicas com preços.

### 🎨 Interface

**Botão "🔍 Procurar e Adicionar Exames"** - Acesso directo à pesquisa no formulário de criação de listas.

**Modal Responsivo** - Janela de pesquisa elegante com scroll, contador de selecionados e botões de ação.

**Feedback Visual** - Exames selecionados ficam destacados a verde para fácil identificação.

### 🚀 Fluxo de Trabalho

1. Clique em "+ Nova Lista"
2. Clique em "🔍 Procurar e Adicionar Exames"
3. Pesquise por nome (ex: "glucose") ou código
4. Clique nos exames desejados para selecionar
5. Clique em "Adicionar Selecionados"
6. Os códigos aparecem automaticamente na caixa de texto
7. Guarde a lista

### 🔧 Melhorias Técnicas

**Carregamento Assíncrono** - Base de dados MCDT carregada em segundo plano.

**Pesquisa Eficiente** - Filtragem rápida por nome ou código.

**Gestão de Estado** - Seleção múltipla com Set() para performance optimizada.


## Versão 1.3.1 - Custo Total por Lista (9 Nov 2025)

### 💰 Nova Funcionalidade

**Cálculo Automático de Custos** - Cada lista personalizada agora mostra o custo total dos exames incluídos.

**Exibição Clara** - O custo aparece junto ao número de exames (ex: "5 exame(s) • €12.40").

**Cálculo Inteligente** - Apenas soma os exames que têm preço disponível na base de dados.

**Formatação Profissional** - Valores mostrados com 2 casas decimais e símbolo €.

### 🎨 Exemplo Visual

Antes:
```
Rotina Básica
5 exame(s)
```

Agora:
```
Rotina Básica
5 exame(s) • €12.40
```

### 🔧 Detalhes Técnicos

**Função calculateListCost()** - Percorre os códigos da lista e soma os preços encontrados na base de dados.

**Validação de Preços** - Ignora códigos sem preço ou com "N/D".

**Performance** - Cálculo eficiente em tempo real ao carregar as listas.

### 💡 Benefícios

**Planeamento Financeiro** - Saiba quanto vai custar cada lista antes de executar.

**Comparação de Listas** - Compare custos entre diferentes conjuntos de exames.

**Transparência** - Informação clara sobre os custos dos MCDT prescritos.


## Versão 2.0.0 - Base de Dados Completa (9 Nov 2025)

### 🎉 Actualização Major

**Base de Dados Completa** - Todas as áreas de MCDT agora incluídas! De 266 para **692 códigos**.

### 📚 Áreas Incluídas

- **A - ANÁLISES CLÍNICAS** (266 códigos)
- **M - RADIOLOGIA** (168 códigos)
- **G - MEDICINA FÍSICA E REABILITAÇÃO** (63 códigos)
- **I - PNEUMOLOGIA/IMUNOALERGOLOGIA** (50 códigos)
- **Z - EXAMES COMUNS** (38 códigos)
- **H - ORL** (35 códigos)
- **D - MEDICINA NUCLEAR** (15 códigos)
- **F - ENDOSCOPIA GASTRENTEROLÓGICA** (15 códigos)
- **B - ANATOMIA PATOLÓGICA** (13 códigos)
- **L - NEUROFISIOLOGIA** (10 códigos)
- **C - CARDIOLOGIA** (10 códigos)
- **J - UROLOGIA** (5 códigos)
- **E - ELECTROENCEFALOGRAFIA** (4 códigos)

### ✨ Nova Funcionalidade

**Filtro por Área** - Dropdown para filtrar exames por área clínica na janela de pesquisa.

**Pesquisa Combinada** - Filtre por área E pesquise por nome/código simultaneamente.

**Cobertura Total** - Acesso a praticamente todos os MCDT convencionados em Portugal.

### 🎨 Interface Melhorada

**Dropdown de Áreas** - Seleccione "Todas as Áreas" ou uma área específica antes de pesquisar.

**Ordenação Alfabética** - Áreas aparecem ordenadas alfabeticamente no filtro.

**Resultados Filtrados** - Pesquisa responde tanto ao filtro de área como ao termo de pesquisa.

### 📊 Estatísticas

- **Total de códigos:** 692
- **Áreas cobertas:** 13
- **Preços incluídos:** Sim (tabela 2025)
- **Pesquisa:** Por nome, código e área

### 🚀 Impacto

**Cobertura Completa** - Não apenas análises clínicas, mas também imagiologia, cardiologia, endoscopia, etc.

**Maior Utilidade** - Útil para todas as especialidades médicas.

**Pesquisa Eficiente** - Encontre qualquer exame rapidamente com filtros combinados.
