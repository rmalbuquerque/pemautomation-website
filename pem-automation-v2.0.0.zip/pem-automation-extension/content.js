// Content script - Injetado em todas as páginas
let isExecuting = false;

// Configurações de velocidade optimizadas
const TIMING = {
    AFTER_TYPE: 100,        // Tempo após digitar código
    AFTER_CLICK: 200,       // Tempo após clicar adicionar
    BETWEEN_EXAMS: 150,     // Tempo entre exames
    WAIT_SUCCESS_MAX: 3000, // Tempo máximo para aguardar sucesso
    POLL_INTERVAL: 50       // Intervalo de verificação de sucesso
};

// Verificar se estamos numa página PEM (ajustar URL conforme necessário)
function isPEMPage() {
    // Procurar por elementos característicos do PEM
    const pemIndicators = [
        document.querySelector('input[placeholder*="Código MCDT"]'),
        document.querySelector('input[name*="mcdt"]'),
        document.querySelector('button:contains("ADICIONAR À REQUISIÇÃO")'),
        document.querySelector('.pem-container'),
        document.title.includes('PEM'),
        document.querySelector('input[id*="mcdt"]'),
        document.querySelector('textarea[name*="informacao"]')
    ];
    
    return pemIndicators.some(indicator => indicator !== null);
}

// Encontrar campo de código MCDT
function findMCDTCodeField() {
    // Tentar várias estratégias para encontrar o campo
    const selectors = [
        'input[placeholder*="Código MCDT"]',
        'input[name*="codigo"]',
        'input[id*="codigo"]',
        'input[name*="mcdt"]',
        'input[id*="mcdt"]'
    ];
    
    for (const selector of selectors) {
        const field = document.querySelector(selector);
        if (field) return field;
    }
    
    // Procurar por label "Código MCDT" e encontrar input próximo
    const labels = Array.from(document.querySelectorAll('label'));
    const mcdtLabel = labels.find(label => label.textContent.includes('Código MCDT'));
    
    if (mcdtLabel) {
        const input = mcdtLabel.nextElementSibling?.querySelector('input') || 
                     mcdtLabel.parentElement?.querySelector('input');
        if (input) return input;
    }
    
    return null;
}

// Encontrar botão "Adicionar à Requisição"
function findAddButton() {
    // Procurar botão com texto específico
    const buttons = Array.from(document.querySelectorAll('button, input[type="button"], input[type="submit"]'));
    
    const addButton = buttons.find(btn => {
        const text = btn.textContent || btn.value || '';
        return text.includes('ADICIONAR') && text.includes('REQUISIÇÃO');
    });
    
    if (addButton) return addButton;
    
    // Procurar por classe ou ID
    const selectors = [
        'button[id*="adicionar"]',
        'button[class*="adicionar"]',
        'input[value*="ADICIONAR"]'
    ];
    
    for (const selector of selectors) {
        const btn = document.querySelector(selector);
        if (btn) return btn;
    }
    
    return null;
}

// Encontrar tabela de requisição (onde aparecem os exames adicionados)
function findRequisitionTable() {
    const selectors = [
        'table[id*="requisicao"]',
        'table[class*="requisicao"]',
        'div[id*="MCDT REQUISIÇÃO"]',
        'div[class*="mcdt-list"]'
    ];
    
    for (const selector of selectors) {
        const table = document.querySelector(selector);
        if (table) return table;
    }
    
    // Procurar por cabeçalho "MCDT REQUISIÇÃO"
    const headers = Array.from(document.querySelectorAll('h2, h3, div'));
    const reqHeader = headers.find(h => h.textContent.includes('MCDT REQUISIÇÃO'));
    
    if (reqHeader) {
        return reqHeader.parentElement?.querySelector('table') || 
               reqHeader.nextElementSibling;
    }
    
    return null;
}

// Aguardar elemento aparecer
function waitForElement(selector, timeout = 5000) {
    return new Promise((resolve, reject) => {
        const element = document.querySelector(selector);
        if (element) {
            resolve(element);
            return;
        }
        
        const observer = new MutationObserver((mutations, obs) => {
            const element = document.querySelector(selector);
            if (element) {
                obs.disconnect();
                resolve(element);
            }
        });
        
        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
        
        setTimeout(() => {
            observer.disconnect();
            reject(new Error('Timeout waiting for element'));
        }, timeout);
    });
}

// Simular digitação humana
function simulateTyping(element, text) {
    element.focus();
    element.value = '';
    
    // Disparar eventos de input
    element.value = text;
    
    const events = [
        new Event('input', { bubbles: true }),
        new Event('change', { bubbles: true }),
        new KeyboardEvent('keyup', { bubbles: true })
    ];
    
    events.forEach(event => element.dispatchEvent(event));
}

// Simular clique
function simulateClick(element) {
    const events = [
        new MouseEvent('mousedown', { bubbles: true }),
        new MouseEvent('mouseup', { bubbles: true }),
        new MouseEvent('click', { bubbles: true })
    ];
    
    events.forEach(event => element.dispatchEvent(event));
}

// Aguardar tempo
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// Detectar se o campo foi limpo (indicação de sucesso)
async function waitForFieldClear(field, timeout = TIMING.WAIT_SUCCESS_MAX) {
    const startTime = Date.now();
    
    while (Date.now() - startTime < timeout) {
        if (!field.value || field.value.trim() === '') {
            return true; // Campo limpo = sucesso
        }
        await sleep(TIMING.POLL_INTERVAL);
    }
    
    return false; // Timeout
}

// Detectar se exame foi adicionado à tabela
async function waitForExamInTable(code, timeout = TIMING.WAIT_SUCCESS_MAX) {
    const startTime = Date.now();
    const table = findRequisitionTable();
    
    if (!table) {
        // Se não encontrar tabela, usar método alternativo
        return true;
    }
    
    while (Date.now() - startTime < timeout) {
        const tableText = table.textContent || '';
        if (tableText.includes(code)) {
            return true; // Código apareceu na tabela
        }
        await sleep(TIMING.POLL_INTERVAL);
    }
    
    return false; // Timeout
}

// Detectar mensagens de erro
function hasErrorMessage() {
    const errorSelectors = [
        '.error',
        '.alert-danger',
        '[class*="erro"]',
        '[class*="error"]'
    ];
    
    for (const selector of errorSelectors) {
        const errorElement = document.querySelector(selector);
        if (errorElement && errorElement.offsetParent !== null) {
            // Elemento de erro visível
            return true;
        }
    }
    
    return false;
}

// Aguardar sucesso com detecção inteligente
async function waitForSuccess(code, field) {
    const startTime = Date.now();
    
    // Estratégia 1: Aguardar campo limpar
    const fieldCleared = await waitForFieldClear(field, TIMING.WAIT_SUCCESS_MAX);
    
    if (fieldCleared) {
        const elapsed = Date.now() - startTime;
        console.log(`✓ Exame ${code} adicionado em ${elapsed}ms`);
        return { success: true, method: 'field_clear', time: elapsed };
    }
    
    // Estratégia 2: Verificar se apareceu na tabela
    const inTable = await waitForExamInTable(code, 500);
    
    if (inTable) {
        const elapsed = Date.now() - startTime;
        console.log(`✓ Exame ${code} detectado na tabela em ${elapsed}ms`);
        return { success: true, method: 'table_detection', time: elapsed };
    }
    
    // Estratégia 3: Verificar se há erro
    if (hasErrorMessage()) {
        const elapsed = Date.now() - startTime;
        console.log(`✗ Erro detectado ao adicionar ${code}`);
        return { success: false, method: 'error_detected', time: elapsed };
    }
    
    // Fallback: Assumir sucesso se não houver erro óbvio
    const elapsed = Date.now() - startTime;
    console.log(`? Exame ${code} - status incerto (assumindo sucesso)`);
    return { success: true, method: 'timeout_fallback', time: elapsed };
}

// Adicionar um código MCDT com detecção inteligente
async function addMCDTCode(code) {
    const codeField = findMCDTCodeField();
    const addButton = findAddButton();
    
    if (!codeField) {
        throw new Error('Campo de código MCDT não encontrado');
    }
    
    if (!addButton) {
        throw new Error('Botão "Adicionar à Requisição" não encontrado');
    }
    
    // Guardar valor anterior do campo
    const previousValue = codeField.value;
    
    // Preencher código
    simulateTyping(codeField, code);
    await sleep(TIMING.AFTER_TYPE);
    
    // Clicar no botão adicionar
    simulateClick(addButton);
    await sleep(TIMING.AFTER_CLICK);
    
    // Aguardar sucesso com detecção inteligente
    const result = await waitForSuccess(code, codeField);
    
    if (!result.success) {
        throw new Error(`Falha ao adicionar código ${code}`);
    }
    
    return result;
}

// Executar lista de códigos MCDT
async function executeMCDTList(codes, listName) {
    if (isExecuting) {
        showNotification('Já existe uma execução em curso', 'warning');
        return;
    }
    
    isExecuting = true;
    const startTime = Date.now();
    
    showNotification(`🚀 Iniciando lista "${listName}" (${codes.length} exames)`, 'info');
    
    let successCount = 0;
    let errorCount = 0;
    const timings = [];
    
    for (let i = 0; i < codes.length; i++) {
        const code = codes[i];
        const examStartTime = Date.now();
        
        try {
            showNotification(`⚡ ${i + 1}/${codes.length}: ${code}`, 'info', 1500);
            
            const result = await addMCDTCode(code);
            const examTime = Date.now() - examStartTime;
            
            successCount++;
            timings.push(examTime);
            
            console.log(`Exame ${code}: ${examTime}ms (método: ${result.method})`);
            
            // Pausa curta entre exames
            await sleep(TIMING.BETWEEN_EXAMS);
            
        } catch (error) {
            const examTime = Date.now() - examStartTime;
            console.error(`Erro ao adicionar código ${code}:`, error);
            errorCount++;
            timings.push(examTime);
            
            showNotification(`❌ Erro no código ${code}`, 'error', 2000);
            await sleep(500); // Pausa maior em caso de erro
        }
    }
    
    isExecuting = false;
    
    // Calcular estatísticas
    const totalTime = Date.now() - startTime;
    const avgTime = timings.length > 0 ? timings.reduce((a, b) => a + b, 0) / timings.length : 0;
    
    console.log(`
╔════════════════════════════════════════╗
║  ESTATÍSTICAS DE EXECUÇÃO              ║
╠════════════════════════════════════════╣
║  Lista: ${listName.padEnd(29)} ║
║  Total de exames: ${codes.length.toString().padEnd(18)} ║
║  Sucessos: ${successCount.toString().padEnd(27)} ║
║  Erros: ${errorCount.toString().padEnd(30)} ║
║  Tempo total: ${(totalTime/1000).toFixed(2)}s${' '.repeat(22 - (totalTime/1000).toFixed(2).length)} ║
║  Tempo médio/exame: ${(avgTime/1000).toFixed(2)}s${' '.repeat(15 - (avgTime/1000).toFixed(2).length)} ║
║  Velocidade: ${(codes.length / (totalTime/1000)).toFixed(1)} exames/s${' '.repeat(16 - (codes.length / (totalTime/1000)).toFixed(1).length)} ║
╚════════════════════════════════════════╝
    `);
    
    // Mostrar resultado final
    if (errorCount === 0) {
        showNotification(
            `✅ "${listName}" concluída! ${successCount} exames em ${(totalTime/1000).toFixed(1)}s (${(avgTime/1000).toFixed(2)}s/exame)`, 
            'success', 
            6000
        );
    } else {
        showNotification(
            `⚠️ Concluída com erros: ${successCount} ✓, ${errorCount} ✗ em ${(totalTime/1000).toFixed(1)}s`, 
            'warning', 
            6000
        );
    }
}

// Mostrar notificação na página
function showNotification(message, type = 'info', duration = 3000) {
    // Remover notificação anterior se existir
    const existing = document.getElementById('pem-automation-notification');
    if (existing) existing.remove();
    
    const notification = document.createElement('div');
    notification.id = 'pem-automation-notification';
    notification.className = `pem-notification pem-notification-${type}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Animar entrada
    setTimeout(() => {
        notification.classList.add('pem-notification-show');
    }, 10);
    
    // Remover após duração
    setTimeout(() => {
        notification.classList.remove('pem-notification-show');
        setTimeout(() => notification.remove(), 300);
    }, duration);
}



// Listener para mensagens
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'executeMCDTList') {
        executeMCDTList(request.codes, request.listName);
        sendResponse({ success: true });
    }
    return true;
});

// A extensão está pronta para receber comandos do popup
console.log('PEM Automation: Content script carregado e pronto');
