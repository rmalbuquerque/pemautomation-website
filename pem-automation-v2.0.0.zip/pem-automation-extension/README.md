# 🏥 PEM Automation - Extensão para Prescrição Automática de MCDT

**Versão:** 1.0.0  
**Autor:** Manus AI  
**Data:** 6 de Novembro de 2025

## Descrição

A extensão **PEM Automation** é uma ferramenta desenvolvida para automatizar o processo de prescrição de exames MCDT (Meios Complementares de Diagnóstico e Terapêutica) no sistema PEM (Prescrição Eletrónica Médica). Esta extensão permite aos profissionais de saúde criar listas pré-definidas de exames e executá-las automaticamente com um simples clique, reduzindo significativamente o tempo necessário para prescrever múltiplos exames.

## Características Principais

A extensão oferece um conjunto de funcionalidades desenhadas para maximizar a eficiência do processo de prescrição:

**Listas Pré-definidas**: É possível criar e guardar múltiplas listas de códigos MCDT para diferentes cenários clínicos, como rotinas básicas, check-ups completos ou protocolos específicos. Cada lista pode conter quantos códigos forem necessários e é armazenada localmente no navegador para acesso rápido.

**Execução Automática**: Ao selecionar uma lista, a extensão introduz automaticamente cada código MCDT no campo apropriado e clica no botão "Adicionar à Requisição", simulando o processo manual mas com velocidade e precisão superiores. O sistema aguarda entre cada inserção para garantir que o sistema PEM processa corretamente cada exame.

**Botão Flutuante**: Um botão discreto mas facilmente acessível aparece no canto inferior direito de qualquer página web. Este botão permite aceder rapidamente às funcionalidades da extensão sem interromper o fluxo de trabalho, mantendo-se sempre visível mas sem obstruir o conteúdo da página.

**Interface Intuitiva**: A interface foi desenhada com foco na simplicidade e usabilidade, apresentando uma experiência visual moderna e profissional. O popup da extensão permite gerir listas, criar novas configurações e executar prescrições com apenas alguns cliques.

**Notificações em Tempo Real**: Durante a execução de uma lista, o sistema apresenta notificações visuais na página indicando o progresso, sucessos e eventuais erros. Estas notificações aparecem de forma não intrusiva no canto superior direito e desaparecem automaticamente.

## Requisitos do Sistema

Para utilizar a extensão PEM Automation, é necessário cumprir os seguintes requisitos:

**Navegador**: A extensão é compatível com navegadores baseados em Chromium, incluindo Microsoft Edge (versão 88 ou superior) e Google Chrome (versão 88 ou superior). Outros navegadores baseados em Chromium, como Brave ou Opera, também devem funcionar correctamente.

**Sistema Operativo**: A extensão funciona em qualquer sistema operativo que suporte os navegadores mencionados, incluindo Windows 10/11, macOS 10.14 ou superior, e distribuições Linux modernas.

**Acesso ao Sistema PEM**: É necessário ter credenciais válidas e acesso ao sistema PEM para utilizar as funcionalidades de automação. A extensão não fornece nem armazena credenciais de acesso.

## Instalação

O processo de instalação da extensão é simples e directo, seguindo os passos padrão para instalação de extensões não publicadas na loja oficial.

### Passo 1: Extrair os Ficheiros

Após fazer o download do ficheiro `pem-automation-extension.zip`, extraia o seu conteúdo para uma pasta no seu computador. Recomenda-se escolher uma localização permanente, como `C:\Extensions\PEM-Automation` no Windows ou `~/Extensions/PEM-Automation` no macOS/Linux, uma vez que a extensão precisa de permanecer nesta localização para continuar a funcionar.

### Passo 2: Aceder ao Modo de Programador

Abra o Microsoft Edge ou Google Chrome e aceda à página de gestão de extensões. No Edge, pode fazê-lo digitando `edge://extensions/` na barra de endereços. No Chrome, utilize `chrome://extensions/`. Alternativamente, pode aceder através do menu do navegador em **Definições → Extensões**.

Na página de extensões, localize e active a opção **Modo de programador** (Developer Mode) no canto superior direito. Esta opção permite instalar extensões que não estão publicadas na loja oficial.

### Passo 3: Carregar a Extensão

Com o modo de programador activado, surgirão novas opções na página. Clique no botão **Carregar sem compactação** (Load unpacked) ou **Carregar extensão descompactada**. Navegue até à pasta onde extraiu os ficheiros da extensão e seleccione-a. O navegador irá carregar a extensão e esta ficará imediatamente disponível para utilização.

### Passo 4: Verificar a Instalação

Após o carregamento, deverá ver a extensão **PEM Automation** listada na página de extensões com um ícone de hospital. Certifique-se de que a extensão está activada (o botão de alternância deve estar na posição "ligado"). Pode também fixar a extensão à barra de ferramentas clicando no ícone de extensões do navegador e seleccionando o ícone de alfinete junto à PEM Automation.

## Utilização

A utilização da extensão divide-se em duas fases principais: a configuração de listas pré-definidas e a execução dessas listas no sistema PEM.

### Criar uma Lista Pré-definida

Para criar uma nova lista de exames MCDT, comece por clicar no botão flutuante que aparece no canto inferior direito de qualquer página web. Este botão apresenta um ícone de hospital e o texto "PEM Auto". Ao clicar, abrirá o popup da extensão.

No popup, clique no botão verde **+ Nova Lista**. Será apresentado um formulário onde deve introduzir as seguintes informações:

**Nome da Lista**: Escolha um nome descritivo que identifique claramente o propósito da lista, como "Rotina Básica", "Check-up Completo", "Pré-operatório Standard" ou "Seguimento Oncológico". Este nome será utilizado para identificar a lista posteriormente.

**Códigos MCDT**: Introduza os códigos dos exames que pretende incluir na lista, colocando um código por linha. Por exemplo, para uma rotina básica, poderia introduzir:

```
1080.9
427.8
442.0
```

Estes códigos correspondem respectivamente a hemograma com plaquetas, creatinina e glicose. Pode incluir quantos códigos forem necessários, sem limite de quantidade.

Após preencher os campos, clique no botão **💾 Guardar Lista**. A lista ficará guardada localmente no navegador e aparecerá na lista principal de listas pré-definidas. Pode criar quantas listas diferentes forem necessárias para os diversos cenários clínicos que encontra na sua prática.

### Executar uma Lista no Sistema PEM

Para utilizar uma lista pré-definida, comece por aceder ao sistema PEM e navegar até à página de prescrição de MCDT. Certifique-se de que já seleccionou o utente e que está na página onde normalmente introduziria manualmente os códigos MCDT.

Clique no botão flutuante **PEM Auto** no canto inferior direito da página. No popup que surge, verá todas as listas que criou anteriormente. Cada lista mostra o nome que lhe atribuiu e o número de exames que contém.

Clique no botão **▶ Executar** junto à lista que pretende utilizar. A extensão começará imediatamente a processar os códigos MCDT da lista. Verá notificações no canto superior direito da página indicando o progresso da execução, mostrando qual o exame que está a ser adicionado e quantos faltam processar.

O processo é automático e não requer intervenção adicional. A extensão introduz cada código no campo apropriado, aguarda o processamento do sistema e clica no botão "Adicionar à Requisição". Entre cada exame, há uma pausa breve para garantir que o sistema PEM processa correctamente a informação.

Quando todos os exames forem adicionados, surgirá uma notificação final indicando o sucesso da operação e quantos exames foram adicionados. Se ocorrerem erros durante o processo, estes serão reportados nas notificações, permitindo identificar e corrigir manualmente os casos problemáticos.

### Gerir Listas Existentes

As listas criadas podem ser geridas a qualquer momento através do popup da extensão. Cada lista apresenta três botões de acção:

**Executar (▶)**: Inicia a execução automática da lista, conforme descrito anteriormente.

**Editar (✏️)**: Permite modificar o nome da lista ou os códigos MCDT incluídos. Ao clicar, o formulário de edição abre com os dados actuais, permitindo fazer as alterações necessárias. Após modificar, clique em **💾 Atualizar Lista** para guardar as mudanças.

**Eliminar (🗑️)**: Remove permanentemente a lista. Será apresentada uma confirmação antes da eliminação para evitar remoções acidentais.

## Estrutura Técnica

A extensão foi desenvolvida utilizando tecnologias web standard e segue as melhores práticas de desenvolvimento de extensões para navegadores Chromium. A arquitectura é composta por três componentes principais que trabalham em conjunto:

### Manifest (manifest.json)

O ficheiro manifest define a configuração da extensão, incluindo permissões, scripts e metadados. Utiliza a versão 3 do manifest, que é o standard mais recente e oferece melhor segurança e desempenho. As permissões solicitadas são mínimas e incluem apenas `storage` para guardar as listas localmente, `activeTab` para interagir com a página activa e `scripting` para injectar código nas páginas web.

### Interface do Utilizador (popup.html e popup.js)

O popup apresenta a interface principal da extensão, onde os utilizadores podem criar, editar, eliminar e executar listas de MCDT. A interface foi desenhada com HTML5 e CSS3 moderno, utilizando gradientes, sombras e animações subtis para criar uma experiência visual agradável. O JavaScript gere toda a lógica de interacção, incluindo a comunicação com o armazenamento local e o envio de mensagens para o content script.

### Content Script (content.js e content.css)

O content script é injectado em todas as páginas web e é responsável por criar o botão flutuante e executar a automação no sistema PEM. Quando recebe uma mensagem do popup para executar uma lista, o script localiza os campos relevantes na página PEM, preenche os códigos MCDT e simula os cliques necessários. O script utiliza técnicas de detecção robustas para encontrar os elementos correctos, mesmo que a estrutura da página varie ligeiramente.

## Resolução de Problemas

Durante a utilização da extensão, podem surgir algumas situações que requerem atenção. Esta secção apresenta os problemas mais comuns e as respectivas soluções.

### O Botão Flutuante Não Aparece

Se o botão flutuante não está visível na página, verifique primeiro se a extensão está activada na página de gestão de extensões do navegador. Algumas páginas podem ter políticas de segurança que impedem a execução de extensões. Tente recarregar a página pressionando F5 ou Ctrl+R. Se o problema persistir, verifique se não existe outro elemento da página a sobrepor o botão no canto inferior direito.

### A Execução Falha ou Não Adiciona Exames

Se a extensão não consegue adicionar os exames automaticamente, a causa mais provável é que a estrutura da página PEM mudou ou os selectores utilizados não correspondem aos elementos actuais. Verifique se consegue adicionar exames manualmente na página. Se conseguir, o problema pode estar na velocidade de execução. Pode ser necessário ajustar os tempos de espera no código da extensão.

Certifique-se também de que os códigos MCDT na lista estão correctos e são válidos no sistema PEM. Códigos inválidos ou inexistentes não serão adicionados e gerarão erros.

### Notificações de Erro Durante a Execução

Se surgem notificações de erro durante a execução de uma lista, anote qual o código MCDT que causou o problema. Verifique se esse código é válido e se pode ser adicionado manualmente. Se o código for válido mas a extensão não consegue adicioná-lo, pode haver um problema de sincronização com o sistema PEM. Tente executar a lista novamente, uma vez que problemas temporários de rede ou carregamento da página podem causar falhas ocasionais.

### A Extensão Não Guarda as Listas

Se as listas criadas desaparecem após fechar o navegador, verifique se o navegador tem permissões para armazenar dados localmente. Alguns modos de navegação privada ou configurações de privacidade muito restritivas podem impedir o armazenamento de dados. Certifique-se de que está a utilizar o navegador em modo normal e que não tem extensões de limpeza automática de dados activadas.

## Segurança e Privacidade

A segurança e privacidade dos dados são aspectos fundamentais no desenvolvimento desta extensão, especialmente considerando que se destina a ser utilizada em contexto clínico com dados sensíveis.

**Armazenamento Local**: Todas as listas de códigos MCDT são armazenadas exclusivamente no navegador do utilizador, utilizando a API de armazenamento local do Chrome. Nenhum dado é enviado para servidores externos ou partilhado com terceiros. As listas permanecem no dispositivo do utilizador e só são acessíveis através do seu navegador.

**Sem Recolha de Dados**: A extensão não recolhe, transmite ou armazena qualquer informação sobre os utilizadores, os utentes do sistema PEM ou os exames prescritos. Não existem mecanismos de telemetria, análise ou rastreamento implementados. A extensão funciona completamente offline após a instalação, excepto quando interage com o sistema PEM através do navegador.

**Permissões Mínimas**: A extensão solicita apenas as permissões estritamente necessárias para o seu funcionamento. Não tem acesso a histórico de navegação, passwords, dados de formulários ou qualquer outra informação sensível armazenada no navegador. As permissões concedidas limitam-se à interacção com a página activa quando o utilizador executa explicitamente uma lista.

**Código Aberto**: Todo o código da extensão está disponível para inspeção nos ficheiros fornecidos. Não existem componentes ofuscados ou encriptados. Profissionais de TI ou programadores podem revisar o código para verificar a ausência de comportamentos maliciosos ou recolha de dados.

**Responsabilidade do Utilizador**: É importante notar que a extensão automatiza acções que o utilizador normalmente executaria manualmente. A responsabilidade pela prescrição correcta de exames permanece sempre com o profissional de saúde. A extensão deve ser utilizada como ferramenta auxiliar, e todas as prescrições devem ser revistas antes de serem finalizadas no sistema PEM.

## Limitações Conhecidas

A extensão foi desenvolvida com base nas imagens fornecidas do sistema PEM e pode ter algumas limitações decorrentes desta abordagem:

**Dependência da Estrutura da Página**: A automação depende da estrutura HTML da página PEM permanecer relativamente estável. Actualizações significativas ao sistema PEM podem requerer ajustes no código da extensão para manter a compatibilidade.

**Campos Adicionais**: A versão actual da extensão preenche apenas o código MCDT e clica no botão de adicionar. Campos adicionais como Produto, Lado, Quantidade, Informação Clínica ou opções de Urgente/Domicílio não são preenchidos automaticamente. Estes campos devem ser configurados manualmente antes ou depois da execução da lista, conforme necessário.

**Validação de Códigos**: A extensão não valida se os códigos MCDT introduzidos são válidos ou apropriados para o contexto clínico. Esta validação deve ser feita pelo utilizador ao criar as listas e ao rever as prescrições no sistema PEM.

**Gestão de Erros**: Embora a extensão detecte e reporte erros durante a execução, a capacidade de recuperação automática é limitada. Se um código falhar, a extensão continua com os restantes códigos da lista, mas não tenta novamente o código que falhou.

## Suporte e Desenvolvimento Futuro

Esta extensão foi desenvolvida como solução inicial baseada nas informações disponíveis. Melhorias e ajustes podem ser necessários após utilização em ambiente real com o sistema PEM actual.

**Personalização**: O código da extensão pode ser modificado para adicionar funcionalidades adicionais, ajustar tempos de espera ou adaptar-se a variações específicas do sistema PEM utilizado na sua instituição.

**Actualizações**: Se o sistema PEM sofrer alterações significativas que quebrem a funcionalidade da extensão, será necessário actualizar os selectores e a lógica de automação no ficheiro `content.js`.

**Feedback**: A utilização em contexto real pode revelar situações não previstas durante o desenvolvimento. Recomenda-se testar a extensão cuidadosamente em ambiente controlado antes de utilizar em produção.

## Notas Finais

A extensão PEM Automation foi desenvolvida com o objectivo de aumentar a eficiência dos profissionais de saúde na prescrição de exames MCDT, reduzindo o tempo gasto em tarefas repetitivas e minimizando erros de digitação. No entanto, é fundamental que os utilizadores compreendam que a ferramenta é um auxiliar e não substitui o julgamento clínico ou a responsabilidade profissional.

Recomenda-se que as listas pré-definidas sejam criadas com cuidado, verificando a adequação dos exames incluídos para cada cenário clínico. Após a execução automática de uma lista, deve sempre rever os exames adicionados no sistema PEM antes de finalizar a prescrição, garantindo que estão correctos e apropriados para o utente em questão.

A utilização desta extensão deve estar em conformidade com as políticas de segurança da informação e protecção de dados da instituição onde é utilizada. Em caso de dúvidas sobre a adequação da ferramenta ao contexto específico, consulte os responsáveis de sistemas de informação ou segurança da sua organização.

---

**Desenvolvido por Manus AI**  
**Novembro de 2025**
